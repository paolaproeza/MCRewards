var Mctinder = artifacts.require("Mctinder");

module.exports = function(deployer) {
  deployer.deploy(Mctinder);
};